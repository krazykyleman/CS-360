package com.snhu.ui;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameField;
    private EditText passwordField;
    private Button loginButton;
    private Button createAccountButton;
    private UserDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameField = findViewById(R.id.username_field);
        passwordField = findViewById(R.id.password_field);
        loginButton = findViewById(R.id.login_button);
        createAccountButton = findViewById(R.id.create_account_button);
        dbHelper = new UserDatabaseHelper(this);

        loginButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                loginUser();
            }

        });

        createAccountButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                registerUser();

            }

        });

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);  // Add this line

        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_LONG).show();
            }
        }
    }


    private void loginUser() {
        String username = usernameField.getText().toString();
        String password = passwordField.getText().toString();

        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String[] projection = {
                UserDatabaseHelper.COLUMN_ID,
                UserDatabaseHelper.COLUMN_USERNAME,
                UserDatabaseHelper.COLUMN_PASSWORD
        };

        String selection = UserDatabaseHelper.COLUMN_USERNAME + " = ?" + " AND " + UserDatabaseHelper.COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = { username, password };

        Cursor cursor = db.query(
                UserDatabaseHelper.TABLE_USERS,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        if (cursor.moveToFirst()) {
            // Login success
            Intent intent = new Intent(LoginActivity.this, WeightActivity.class);
            startActivity(intent);
        } else {
            // Login fail
            Toast.makeText(LoginActivity.this, "Invalid username or password", Toast.LENGTH_LONG).show();
        }

        cursor.close();
    }


    private void registerUser() {

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserDatabaseHelper.COLUMN_USERNAME, usernameField.getText().toString());
        values.put(UserDatabaseHelper.COLUMN_PASSWORD, passwordField.getText().toString());

        long newRowId = db.insert(UserDatabaseHelper.TABLE_USERS, null, values);

        if (newRowId == -1) {

            Toast.makeText(LoginActivity.this, "Error with saving user", Toast.LENGTH_LONG).show();

        }

        else {

            Toast.makeText(LoginActivity.this, "User saved with row id: " + newRowId, Toast.LENGTH_LONG).show();

        }

    }

}
