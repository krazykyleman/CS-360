package com.snhu.ui;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class WeightDatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "weights.db";
    public static final int DATABASE_VERSION = 1;

    public static final String TABLE_WEIGHTS = "weights";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_WEIGHT = "weight";
    public static final String COLUMN_TIMESTAMP = "timestamp";

    public static final String TABLE_GOAL_WEIGHT = "goal_weight";
    public static final String COLUMN_GOAL_WEIGHT = "goal_weight";

    public WeightDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_WEIGHTS_TABLE = "CREATE TABLE " + TABLE_WEIGHTS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY,"
                + COLUMN_WEIGHT + " REAL,"
                + COLUMN_TIMESTAMP + " INTEGER" + ")";
        db.execSQL(CREATE_WEIGHTS_TABLE);

        String CREATE_GOAL_WEIGHT_TABLE = "CREATE TABLE " + TABLE_GOAL_WEIGHT + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY,"
                + COLUMN_GOAL_WEIGHT + " REAL" + ")";
        db.execSQL(CREATE_GOAL_WEIGHT_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL_WEIGHT);
        onCreate(db);
    }

    public boolean setGoalWeight(double goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);

        db.delete(TABLE_GOAL_WEIGHT, null, null); // delete any previous goal weight

        long result = db.insert(TABLE_GOAL_WEIGHT, null, values);

        db.close();

        return result != -1; // if result == -1, insertion failed
    }
}
