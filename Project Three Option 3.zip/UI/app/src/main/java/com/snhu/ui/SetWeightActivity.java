package com.snhu.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SetWeightActivity extends AppCompatActivity {

    private EditText goalWeightEditText;
    private Button goalWeightButton;
    private WeightDatabaseHelper weightDbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setweight);

        weightDbHelper = new WeightDatabaseHelper(this);

        goalWeightEditText = (EditText) findViewById(R.id.goalWeightEditText);
        goalWeightButton = (Button) findViewById(R.id.goalWeightButton);

        goalWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String goalWeightText = goalWeightEditText.getText().toString();

                if (goalWeightText.isEmpty()) {
                    Toast.makeText(SetWeightActivity.this, "Please enter a weight", Toast.LENGTH_SHORT).show();
                } else {
                    double goalWeight = Double.parseDouble(goalWeightText);
                    boolean success = weightDbHelper.setGoalWeight(goalWeight);

                    if (success) {
                        Toast.makeText(SetWeightActivity.this, "Goal weight set successfully", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(SetWeightActivity.this, MainActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(SetWeightActivity.this, "Error setting goal weight", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
