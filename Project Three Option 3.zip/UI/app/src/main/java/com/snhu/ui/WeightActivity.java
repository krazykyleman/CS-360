package com.snhu.ui;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;

public class WeightActivity extends AppCompatActivity {
    private WeightDatabaseHelper dbHelper;
    private EditText weightInput;
    private Button addButton;
    private Button setGoalWeightButton;  // New button

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight);

        dbHelper = new WeightDatabaseHelper(this);
        weightInput = findViewById(R.id.et_weight);
        addButton = findViewById(R.id.btn_add_weight);
        setGoalWeightButton = findViewById(R.id.btn_set_goal_weight);  // Bind new button

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addWeight(Double.parseDouble(weightInput.getText().toString()));
            }
        });

        // Add an OnClickListener for the new button
        setGoalWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WeightActivity.this, SetWeightActivity.class);
                startActivity(intent);
            }
        });
    }

    public void addWeight(double weight) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WeightDatabaseHelper.COLUMN_WEIGHT, weight);
        values.put(WeightDatabaseHelper.COLUMN_TIMESTAMP, System.currentTimeMillis());

        db.insert(WeightDatabaseHelper.TABLE_WEIGHTS, null, values);
        db.close();

        Toast.makeText(this, "Weight added successfully", Toast.LENGTH_SHORT).show();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            // Simulate sending an SMS
            Toast.makeText(this, "You've reached your goal weight!", Toast.LENGTH_SHORT).show();
        }
    }


    public Cursor getAllWeights() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        return db.query(WeightDatabaseHelper.TABLE_WEIGHTS,
                new String[]{WeightDatabaseHelper.COLUMN_ID, WeightDatabaseHelper.COLUMN_WEIGHT, WeightDatabaseHelper.COLUMN_TIMESTAMP},
                null, null, null, null, WeightDatabaseHelper.COLUMN_TIMESTAMP + " DESC");
    }

    public void updateWeight(int id, double weight) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WeightDatabaseHelper.COLUMN_WEIGHT, weight);

        db.update(WeightDatabaseHelper.TABLE_WEIGHTS, values, WeightDatabaseHelper.COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)});
        db.close();

        Toast.makeText(this, "Weight updated successfully", Toast.LENGTH_SHORT).show();
    }

    public void deleteWeight(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(WeightDatabaseHelper.TABLE_WEIGHTS, WeightDatabaseHelper.COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)});
        db.close();

        Toast.makeText(this, "Weight deleted successfully", Toast.LENGTH_SHORT).show();
    }
}
